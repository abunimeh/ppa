__author__ = 'dcart_000'


class CalibreErrorsData:
    pass


class CalibreErrors:
    @staticmethod
    def metric_naming(file):
        import re
        stage = ""
        denall = re.search(r'.*denall_reuse.*', file, re.I)
        ipall = re.search(r'.*ipall.*', file, re.I)
        drcd = re.search(r'.*drcc.*', file, re.I)
        trclvs = re.search(r'.*lvs.*', file, re.I)
        gden = re.search(r'.*gden.*', file, re.I)
        HV = re.search(r'.*HV.*', file, re.I)
        if denall:
            stage = ' denall reuse'
        elif ipall:
            stage = ' IPall'
        elif drcd:
            stage = ' drcc'
        elif trclvs:
            stage = ' lvs'
        elif gden:
            stage = ' gden'
        elif HV:
            stage = ' HV'
        return stage

    @staticmethod
    def mathcLine(line, regex1):
        import re
        match_words = regex1.replace(" ", "[\s]*")
        line_variables = '.*(%s)[\s]*([-\d\.]*).*' % match_words
        result = re.search(line_variables, line, re.I)
        return result

    @staticmethod
    def replace_space(metric_list):
        import re
        new_name = re.sub(r'[\W]+', "_", metric_list)
        return new_name

    @staticmethod
    def searchfile(file):
        import re
        # Open the file with read only permit
        f = open(file, "r")
        # The variable "lines" is a list containing all lines
        lines = f.readlines()
        # close the file after reading the lines.
        f.close()
        data_items = []
        stage = CalibreErrors.metric_naming(file)
        calibre_errors = CalibreErrorsData()
        for line in lines:
            found_violation = re.search('(TOTAL[\s]*DRC[\s]*Results[\s]*Generated:)[\s]*([-\d\.]*).*', line, re.I)
            if found_violation:
                calibre_errors.found_violation = CalibreErrors.replace_space('calibre' + stage), found_violation.group(2)
                data_items.append(calibre_errors.found_violation)
        return data_items