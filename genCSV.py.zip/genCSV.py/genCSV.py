#!/usr/bin/env python3
# MAIN
# STATUS -- MISSING TOTAL RUNSET ERROR (OF ALL LAYOUT ERROR RUNS OF THE TESTCASE) COUNT METRIC
import csv
import sys
import os
from datetime import datetime
from operator import itemgetter
from FindFiles import findFiles
from QorRpt import QorRpt
from FinalRpt import FinalRpt
from PVTmetric import PVTMetric
from PhysicalRpt import PhysicalRpt
from RunTimeRpt import RunTimeRpt
from clockTree import clockTreeRpt
from Drc_Errors import DRCError
from dpLog import dpLog
from PvPower import PvPower
from CadenceSignOffSum import CadenceSignOffSum
from CadenceGateCount import CadenceGateCount
from CadencePowerReport import CadencePowerRpt
from CadenceAprRunLog import CadenceAprRunLog
from CadenceQorReport import CadenceQorReport
from CadenceViolations import CadenceViolations
from CadenceRunTime import CadenceRunTime
from CadenceStaMaxQor import CadenceStaMaxQor
from CadenceStaMinQor import CadenceStaMinQor
from CalibreErrors import CalibreErrors
#from OtherMetricClass import OtherMetricClass
from TotalDrcErrors import TotalDrcErrors

print("number of arguments received:", (len(sys.argv)-1))
test_cases_list = []
for argument in sys.argv:
    if argument is not sys.argv[0]:
        print(argument)
        test_cases_list.append(argument)

csv_file_exist = 0
tool = "none"
for test_case in test_cases_list:
    print("### Searching:", test_case)
    metricNames = []
    list_of_files = findFiles.search_dir(test_case)
    found_tool_version = 0
    if "cadence" in test_case:
        tool = "cadence"
    elif "synopsys" in test_case:
        tool = "synopsys"
    for file in list_of_files:
        if file.endswith('.qor.rpt'):
            if 'cadence' in tool:
                if 'reports_max' in file:
                    print("ON FILE", file)
                    sta_max_qor = CadenceStaMaxQor.searchfile(file)
                    metricNames.append(sta_max_qor)
                elif 'reports_min' in file:
                    sta_min_qor = CadenceStaMinQor.searchfile(file)
                    metricNames.append(sta_min_qor)
                elif '.final.qor.rpt' in file:
                    cadence_qor = CadenceQorReport.searchfile(file)
                    metricNames.append(cadence_qor)
            else:
                qrpt = QorRpt.searchfile(file)
                metricNames.append(qrpt)
        elif file.endswith('power.power.rpt'):
            ppower = PvPower.searchfile(file)
            metricNames.append(ppower)
        elif file.endswith('dc.log'):
            pvtmetrics = PVTMetric.searchfile(file)
            metricNames.append(pvtmetrics)
        elif file.endswith('icc.log'):
            pvtmetrics = PVTMetric.searchfile(file)
            metricNames.append(pvtmetrics)
        elif file.endswith('link.rpt'):
            pvtmetrics = PVTMetric.searchfile(file)
            metricNames.append(pvtmetrics)
        elif file.endswith('fill.physical.rpt'):
            physicalrpt = PhysicalRpt.searchfile(file)
            metricNames.append(physicalrpt)
        elif file.endswith('run_time.rpt'):
            runtimerpt = RunTimeRpt.searchfile(file)
            metricNames.append(runtimerpt)
        elif file.endswith('cts.clock_tree.rpt'):
            clocktreerpt = clockTreeRpt.searchfile(file)
            metricNames.append(clocktreerpt)
        elif file.endswith('.dp.log'):
            dplog = dpLog.searchfile(file)
            metricNames.append(dplog)
        elif file.endswith('Final_Report.txt'):
            finalrpt = FinalRpt.searchfile(file)
            metricNames.append(finalrpt)
        elif file.endswith('post_route_hold_optDesign.summary'):
            route_design = CadenceSignOffSum.searchfile(file)
            metricNames.append(route_design)
        elif file.endswith('signoff.power.rpt'):
            pwr_rpt_data = CadencePowerRpt.searchfile(file)
            metricNames.append(pwr_rpt_data)
        elif file.endswith('.final.all_violators.rpt'):
            cadence_violations = CadenceViolations.searchfile(file)
            metricNames.append(cadence_violations)
        elif file.endswith('sta.max.log'):
            cadence_runtime = CadenceRunTime.searchfile(file)
            metricNames.append(cadence_runtime)
        elif file.endswith('.sum'):
            print("searching", file)
            calibre_errors = CalibreErrors.searchfile(file)
            metricNames.append(calibre_errors)
        elif file.endswith('LAYOUT_ERRORS'):
            if found_tool_version == 0:
                layout_er = DRCError.searchfile(file)
                for i in range(len(layout_er)):
                    if "drc_tool_version" in layout_er[i]:
                        found_tool_version = 1
                metricNames.append(layout_er)
        elif file.endswith('apr_run.log'):
            apr_run_log = CadenceAprRunLog.searchfile(file)
            metricNames.append(apr_run_log)
        elif file.endswith('block_stats_signoff.rpt'):
            gate_count = CadenceGateCount.searchfile(file)
            metricNames.append(gate_count)

        # else:
        #     other_metrics = other_metric_class.search_file(file)
        #     metricNames.append(other_metrics)

    total_drc_errors = TotalDrcErrors.get_total_count(metricNames)
    if total_drc_errors:
        metricNames.append([("drc_total_viols", total_drc_errors)])
    names, values, temp, syn, apr, drc, pv_max, pv_min, pv_power, pv_noise, sta, calibre = [], [], [], [], [], [], [], [], [], [], [], []

    # This loop is to arrange the files in the correct order
    for metric in metricNames:
        met = tuple(metric)
        for name in range(len(met)):
                if "syn" in met[name][0]:
                    syn.append(met[name])
                    continue
                elif "apr" in met[name][0]:
                    apr.append(met[name])
                    continue
                elif "drc" in met[name][0]:
                    drc.append(met[name])
                    continue
                elif "pv_max" in met[name][0]:
                    pv_max.append(met[name])
                    continue
                elif "pv_min" in met[name][0]:
                    pv_min.append((met[name]))
                    continue
                elif "pv_power" in met[name][0]:
                    pv_power.append((met[name]))
                    continue
                elif "pv_noise" in met[name][0]:
                    pv_noise.append((met[name]))
                    continue
                elif "sta" in met[name][0]:
                    sta.append(met[name])
                    continue
                elif "calibre" in met[name][0]:
                    calibre.append(met[name])


    tool_metric = [("Tool", tool)]
    test_case_metric = [("Testcase_Name", os.path.basename(test_case))]
    date_metric = [("DateTime", str(datetime.now()))]

    temp = [test_case_metric, date_metric, tool_metric, tuple(sorted(syn, key=itemgetter(0))),
        tuple(sorted(apr, key=itemgetter(0))), tuple(sorted(drc, key=itemgetter(0))),
        tuple(sorted(pv_max, key=itemgetter(0))), tuple(sorted(pv_min, key=itemgetter(0))),
        tuple(sorted(pv_power, key=itemgetter(0))), tuple(sorted(pv_noise, key=itemgetter(0))),
        tuple(sorted(sta, key=itemgetter(0))), tuple(sorted(calibre, key=itemgetter(0)))]

    print("metrics found: ")
    for metrics in temp:
        metric = tuple(metrics)
        for name in range(len(metric)):
            print(metric[name])
            # Names and values are concatenated into a string in order to have horizontal column
            names += [metric[name][0]]
            values += [metric[name][1]]
    # print("Metrics found: \n", names, values)
    if csv_file_exist == 0:
        csv_file_exist = 1
        # Creates a csv with the first testcase
        with open(r'Regr_Suite_Runs_Comparison_Data.csv', 'wt') as my_file:
            writer = csv.writer(my_file, lineterminator='\n')
            writer.writerow(names)
            writer.writerow(values)
            writer.writerow(' ')
        my_file.close()
        print('Regr_Suite_Runs_Comparison_Data.csv created with %s' % test_case)
    else:
        # Appends the csv with the following testcases
        with open(r'Regr_Suite_Runs_Comparison_Data.csv', 'a') as my_file:
            writer = csv.writer(my_file, lineterminator='\n')
            writer.writerow(names)
            writer.writerow(values)
            writer.writerow(' ')
        my_file.close()
        print('Regr_Suite_Runs_Comparison_Data.csv appended with %s' % test_case)
