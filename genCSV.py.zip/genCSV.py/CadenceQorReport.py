__author__ = 'dcart_000'


class CadenceQorReportData:
    pass


class CadenceQorReport:
    @staticmethod
    def mathcLine(line, *args):
        import re
        match_words = ""
        no_match = ""
        for arg in args:
            match_words += arg.replace(" ", "[\s]*") + "[\s]*"
        line_variables = '^(%s)[^\d]*([-\d\.:]+)[\s]*([-\d\.:]*).*' % match_words
        result = re.search(line_variables, line, re.I)
        return result

    @staticmethod
    def replace_space(metric_list):
        import re
        new_name = re.sub(r'[\W]+', "_", metric_list)
        return new_name

    @staticmethod
    def searchfile(file):
        # Open the file with read only permit
        f = open(file, "r")
        # The variable "lines" is a list containing all lines
        lines = f.readlines()

        # close the file after reading the lines.
        f.close()
        data_items = []
        qor_rpt_data = CadenceQorReportData()
        for line in lines:
            found_syn_reg = CadenceQorReport.mathcLine(line, 'REG2REG')
            found_cell_count = CadenceQorReport.mathcLine(line, 'Leaf Instance Count')
            found_runtime = CadenceQorReport.mathcLine(line, 'Runtime')
            if found_syn_reg:
                qor_rpt_data.found_syn_reg = CadenceQorReport.replace_space('syn REG2REG WNS'), found_syn_reg.group(2)
                data_items.append(qor_rpt_data.found_syn_reg)
                qor_rpt_data.found_syn_reg = CadenceQorReport.replace_space('syn REG2REG TNS'), found_syn_reg.group(3)
                data_items.append(qor_rpt_data.found_syn_reg)
            elif found_cell_count:
                qor_rpt_data.found_cell_count = CadenceQorReport.replace_space('syn Cell Count'), found_cell_count.group(2)
                data_items.append(qor_rpt_data.found_cell_count)
            elif found_runtime:
                qor_rpt_data.found_runtime = CadenceQorReport.replace_space('syn Run Time'), found_runtime.group(2)
                data_items.append(qor_rpt_data.found_runtime)
        return data_items